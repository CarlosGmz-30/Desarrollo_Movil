import {} from 'react'
import Navigation from './src/config/navigation/Navigation';

export default function App() {
  return (
    <Navigation />
  );
}
